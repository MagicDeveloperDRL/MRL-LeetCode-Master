/*
 * @Author: MRL Liu
 * @Date: 2022-02-08 21:06:36
 * @Description: 无
 * @LastEditTime: 2022-02-11 21:20:50
 * @FilePath: \C++\Leetcode\912.排序数组.cpp
 */
/*
 * @lc app=leetcode.cn id=912 lang=cpp
 *
 * [912] 排序数组
 *
 * https://leetcode-cn.com/problems/sort-an-array/description/
 *
 * algorithms
 * Medium (55.86%)
 * Likes:    470
 * Dislikes: 0
 * Total Accepted:    279.2K
 * Total Submissions: 501.5K
 * Testcase Example:  '[5,2,3,1]'
 *
 * 给你一个整数数组 nums，请你将该数组升序排列。
 * 
 * 
 * 
 * 
 * 
 * 
 * 示例 1：
 * 
 * 
 * 输入：nums = [5,2,3,1]
 * 输出：[1,2,3,5]
 * 
 * 
 * 示例 2：
 * 
 * 
 * 输入：nums = [5,1,1,2,0,0]
 * 输出：[0,0,1,1,2,5]
 * 
 * 
 * 
 * 
 * 提示：
 * 
 * 
 * 1 <= nums.length <= 5 * 10^4
 * -5 * 10^4 <= nums[i] <= 5 * 10^4
 * 
 * 
 */

// @lc code=start
class Solution {
public:
    vector<int> sortArray(vector<int>& nums) {
        // 1.选择排序
        //selectSort(nums);
        // 2.冒泡排序
        bubbleSort(nums);
        return nums;
    }
    /**选择排序**/
    void selectSort(vector<int> &nums) {
        for(int i=0;i<nums.size();i++){
            // 查找未排序序列中的最值
            int minIndex = i;
            for(int j=i+1;j<nums.size();j++){
                if(nums[minIndex]>nums[j]){
                    minIndex=j;
                }
            }
            // 交换nums[i]和nums[minIndex]
            if(minIndex!=i){
                swap(nums[minIndex],nums[i]);
            }
        }
    }
    /**冒泡排序**/
    void bubbleSort(vector<int> &nums) {
        bool swapped;
        for(int i=nums.size()-1;i>0;i--){
            swapped = false;
            // 查找未排序序列中的最值
            for(int j=0;j<i;j++){
                if(nums[j]>nums[j+1]){
                    swap(nums[j],nums[j+1]);
                    swapped=true;
                }
            }
            if (!swapped) break;
        }
    } 
    /**插入排序**/
    void insertSort(vector<int> &nums) {
        int n = nums.size();
        // 从左至右扩展已排序序列
        for (int i = 1; i < n; i++) {
            // 从右至左在已排序序列交换完成排序
            for (int j = i; j > 0; j--) {
                // 交换元素 swap(nums[j], nums[j-1])
                if(nums[j] < nums[j-1]){
                    swap(nums[j],nums[j-1]);
                }
            }
        }
    }
    /**快速排序**/
    void quickSort(vector<int> &nums, int left, int right) {
        if (left >= right) return; 
        int first = left, last = right, key = nums[first];
        while (first < last) {
            // 从右往左找到第一个小于key的值
            while (first < last && nums[last] >= key) --last;
            nums[first] = nums[last];
            // 从左往右找到第一个大于key的值
            while (first < last && nums[first] <= key) ++first;
            nums[last] = nums[first];
        }
        nums[first] = key;
        quickSort(nums, left, first-1);
        quickSort(nums, first+1, right);
    }
    
    /**希尔排序**/
    void shellSort(vector<int> &nums) {
        int n = nums.size();
        int h = 1; 
        while (h < n/3) h = 3*h + 1;//初始增量h应该比n/3稍大，不能直接为n/3（因为必须保证h的最后一个值为1）
        for(;h >= 1;h /= 3) {  // 将数组变为h有序
            // 遍历各个组（从h开始）
            for (int i = h; i < n; i++) {
                //遍历各个组中的所有的元素（从右到左，每个组元素索引间隔h）
                for (int j = i-h; j >= 0; j -= h) {
                    if(nums[j] > nums[j+h]){
                        swap(nums[j],nums[j+h]);// 交换两个元素
                    }
                }
            }
        }
    }
    /**归并排序**/
    void mergeSort(vector<int> &nums, int left, int right){
        // 如果 left == right，表示数组只有一个元素，则不用递归排序
        if (left < right) {
            // 把大的数组分隔成两个数组
            int mid = left + (right - left) / 2;
            // 对左半部分进行排序
            mergeSort(nums, left, mid);
            // 对右半部分进行排序
            mergeSort(nums, mid + 1, right);
            // 将两部分合并后再重新排一次序
            //1、先用一个临时数组把他们合并汇总起来
            vector<int> temp(right - left + 1);
            int i = left;
            int j = mid + 1;
            int k = 0;
            //2、分别选取左右两半部分中的较小值放入临时数组
            while (i <= mid && j <= right) {
                // 谁小先放谁到临时数组
                if (nums[i] < nums[j]) {
                    temp[k++] = nums[i++];
                } else {
                    temp[k++] = nums[j++];
                }
            }
            //3、跳出循环的条件i>mid或者j>right,此时两个小数组中有一个一定没有剩余，另一个有未放入临时数组的数
            // 不知道哪个有剩余，干脆两者都判断下，有剩余直接进循环
            while(i <= mid) temp[k++] = nums[i++];
            while(j <= right) temp[k++] = nums[j++];
            // 此时原有数组的左右部分全部复制到临时数组并已排序，把临时数组复制回原数组
            for (i = 0; i < k; i++) {
                nums[left++] = temp[i];
            }
        }
    }
    /**堆排序**/
    void adjust(vector<int> &nums, int len, int parent){
        int left = 2 * parent + 1; // index的左子节点
        int right = 2 * parent + 2;// index的右子节点

        int maxIdx = parent;//假设父节点为最大值
        // 如果左子节点大于最大值，则最大值设为左子节点
        if (left < len && nums[left] > nums[maxIdx])     maxIdx = left;
        // 如果右子节点大于最大值，则最大值设为右子节点
        if (right < len && nums[right] > nums[maxIdx])     maxIdx = right;
        // 如果此时父节点已经不是最大值
        if (maxIdx != parent) {
            swap(nums[maxIdx], nums[parent]);//交换父节点和最大值，
            adjust(nums, len, maxIdx);//交换后，原来最大值的位置可能已不是其对应子树的最大值，所以要重新调整下
        }
    }
    // 堆排序
    void heapSort(vector<int> &nums){
        int len=nums.size();
        // 构建最大堆
        for(int i = (len-1) / 2 ; i >= 0; i--){
            adjust(nums, len, i);// 负责将i为父节点的子树调整为堆
        }
        // 进行堆排序
        for(int i = len - 1; i >= 1; i--){
            // 把最大堆的堆顶元素与最后一个元素交换
            swap(nums[0], nums[i]); 
            // 调整打乱的最大堆，恢复堆的特性   
            adjust(nums, i, 0);              
        }
    }
};
// @lc code=end


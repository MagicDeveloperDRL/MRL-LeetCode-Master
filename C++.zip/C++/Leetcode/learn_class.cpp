#include<iostream>
#include"date.h"
using namespace std;
using namespace Chrono;
// ��̬��Ա����
Date Date::default_date(22,jan,1901);
// ���캯��
Date::Date(int dd,Month mm,int yy){
    if(yy==0) yy=this->default_date.year();
    if(mm==0) mm=this->default_date.month();
    if(dd==0) dd=this->default_date.day();
    int max;
    switch (mm)
    {
    case feb:
        max=28;
        break;
    case apr:
    case jun:
    case sep:
    case nov:
        max=30;
        break;
    case jan:
    case mar:
    case may:
    case jul:
    case aug:
    case oct:
    case dec:
        max=31;
        break;
    default:
        throw Bad_date();
    }
    if(dd<1||max<<dd) throw Bad_date();
    this->y=yy;
    this->m=mm;
    this->d=dd;
}
// ������Ա����
inline int Date::day() const{ return this->d;}
inline Date::Month Date::month() const{ return Month(this->m);}
inline int Date::year() const{ return this->y;}

Date& Date::add_month(int n){
    if(n==0) return *this;
    else if(n>0){
        int deltay_y=n/12;
        int mm=m+n%12;
        if(12<mm){
            deltay_y++;
            mm-=12;
        }
        this->y+=deltay_y;
        this->m=Month(mm);
        return *this;
    }
    // ��������n
    return *this;
}

int main(){
    Date lvb_day =Date(16,Date::dec,1994);

    system("pause");
    return 0;
}
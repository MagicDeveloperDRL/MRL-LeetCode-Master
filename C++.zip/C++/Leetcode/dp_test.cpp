#include <iostream>
#include<vector>
using namespace std;

// 全局变量，记录递归函数的递归层数
int count = 0;

// 输入 n，打印 n 个 tab 缩进
void printIndent(int n) {
    for (int i = 0; i < n; i++) {
        printf("   ");
    }
}

void bag_problem() {
    // 定义问题
    int bagWeight = 4;// 背包重量
	vector<int> weight = {1, 3, 4}; //	物品重量
    vector<int> value = {15, 20, 30};// 物品价值

    // 一维数组及其初始化
    vector<int> dp(bagWeight + 1, 0);
    // 先遍历每个物品，再遍历不同的背包重量
    for(int i = 0; i < weight.size(); i++) { // 遍历物品
        for(int j = bagWeight; j >= weight[i]; j--) { // 遍历背包容量
			dp[j] = max(dp[j], dp[j - weight[i]] + value[i]);
        }
    }
	//打印dp数组
    for (int j = 0; j <bagWeight + 1; j++){
        cout<<dp[j]<<" ";
    }
    cout <<endl;
}


int main() {
    cout<<"hello world!"<<endl;
    bag_problem();

    system("pause");
    return 0;
}

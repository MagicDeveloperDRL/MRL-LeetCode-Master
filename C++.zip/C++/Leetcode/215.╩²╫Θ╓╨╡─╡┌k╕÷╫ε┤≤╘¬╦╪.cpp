/*
 * @lc app=leetcode.cn id=215 lang=cpp
 *
 * [215] 数组中的第K个最大元素
 *
 * https://leetcode-cn.com/problems/kth-largest-element-in-an-array/description/
 *
 * algorithms
 * Medium (64.69%)
 * Likes:    1476
 * Dislikes: 0
 * Total Accepted:    517.7K
 * Total Submissions: 800K
 * Testcase Example:  '[3,2,1,5,6,4]\n2'
 *
 * 给定整数数组 nums 和整数 k，请返回数组中第 k 个最大的元素。
 * 
 * 请注意，你需要找的是数组排序后的第 k 个最大的元素，而不是第 k 个不同的元素。
 * 
 * 
 * 
 * 示例 1:
 * 
 * 
 * 输入: [3,2,1,5,6,4] 和 k = 2
 * 输出: 5
 * 
 * 
 * 示例 2:
 * 
 * 
 * 输入: [3,2,3,1,2,4,5,5,6] 和 k = 4
 * 输出: 4
 * 
 * 
 * 
 * 提示： 
 * 
 * 
 * 1 
 * -10^4 
 * 
 * 
 */

// @lc code=start
class Solution {
public:
    int findKthLargest(vector<int>& nums, int k) {
        int len = nums.size();
        return quickFind(nums,k-1,0,len-1);//从大到小排序，第k大就是第k-1个索引，返回第k-1个索引的值
    }
    int quickFind(vector<int>& nums, int k,int left,int right){
        int first=left,last=right,key=nums[first];
        // 开始分区
        while(first<last){
            // 从右到左找第一个比key小的数
            while (first<last&&nums[last]<=key)last--; 
            nums[first]=nums[last];
            // 从左到右找第一个比key大的数
            while (first<last&&nums[first]>=key )first++;
            nums[last]=nums[first];
        }
        nums[first]=key;//基准值归位
        // 结束分区
        if(first==k){
            return nums[first];//first是基准值索引，表示第first个
        }
        else if(first>k){
            return quickFind(nums, k,left,first-1);
        }
        else {
            return quickFind(nums, k,first+1,right);
        }
    }
};
// @lc code=end


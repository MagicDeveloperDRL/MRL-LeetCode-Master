/*
 * @Author: MRL Liu
 * @Date: 2022-02-02 21:35:48
 * @Description: 开发环境测试
 * @LastEditTime: 2022-02-16 02:05:33
 * @FilePath: \C++\io_test.cpp
 */
#include<bits/stdc++.h>
using namespace std; 

//int res=0;
// 定义：从(i,j) 出发向四周搜索
// int dfs(vector<string>&matrix,int M,int N,int lastDir,int i,int j,vector<vector<int>>& isVisited){
//     // if(i<0||i>=M||j<0||j>=N){
//     //     return step;
//     // }
//     // if(matrix[i][j]=='X'){
//     //     return step;
//     // }
//     // 如果之前已经记录过则直接返回
//     cout<<i<<" "<<j<<" "<<lastDir<<endl;
//     //if(isVisited[i][j]!=0) return isVisited[i][j];
//     isVisited[i][j]++;

//     if(matrix[i][j]=='E'){
//        return isVisited[i][j];
//     }
    
//     // 尝试向不同的方向走
//     if(i-1>=0&&i-1<M&&j>=0&&j<N&&matrix[i][j]=='B'){
//         int tmp=dfs(matrix,M,N,0,i-1,j,isVisited)+1;
//         if(lastDir==0) isVisited[i][j]=min(isVisited[i][j],tmp+1);// 上
//         else isVisited[i][j]=min(isVisited[i][j],tmp);// 上
//     }
        
        
//     if(i+1>=0&&i+1<M&&j>=0&&j<N&&matrix[i][j]=='B'){
//         int tmp=dfs(matrix,M,N,0,i-1,j,isVisited)+1;
//         if(lastDir==0) isVisited[i][j]=min(isVisited[i][j],tmp+1);// 上
//         else isVisited[i][j]=min(isVisited[i][j],tmp);// 上
//     }
//         if(lastDir!=1) isVisited[i][j]=min(isVisited[i][j],dfs(matrix,M,N,0,i-1,j,isVisited)+2);// 上
//         else isVisited[i][j]=min(isVisited[i][j],dfs(matrix,M,N,1,i+1,j,isVisited)+1);// 下
//     if(i>=0&&i<M&&j-1>=0&&j-1<N&&matrix[i][j]=='B')
//         if(lastDir!=2) isVisited[i][j]=min(isVisited[i][j],dfs(matrix,M,N,0,i-1,j,isVisited)+2);// 上
//         else isVisited[i][j]=min(isVisited[i][j],dfs(matrix,M,N,2,i,j-1,isVisited)+1);// 左
//     if(i>=0&&i<M&&j+1>=0&&j+1<N&&matrix[i][j]=='B')
//         if(lastDir!=3) isVisited[i][j]=min(isVisited[i][j],dfs(matrix,M,N,0,i-1,j,isVisited)+2);// 上
//         else isVisited[i][j]=min(isVisited[i][j],dfs(matrix,M,N,3,i,j+1,isVisited)+1);// 右
//     return isVisited[i][j];

// }
// 定义：从(i,j) 出发向四周搜索
int res=INT_MAX;
vector<pair<int, int>> dirs {{0,1},{0,-1},{-1,0},{1,0}};// 四个方向
void dfs(vector<string>&matrix,int M,int N,pair<int, int> lastDir,int i,int j,int curTime){
    // 如果遇到障碍物
    if(i<0||i>=M||j<0||j>=N||matrix[i][j]=='X'||curTime>=res) return;
    if(matrix[i][j]=='E'){
        res=min(res,curTime);
        return;
    }
    // 标记当前为障碍物
    char temp=matrix[i][j];
    matrix[i][j]='X';
    // 遍历四个方向
    for(pair<int, int>& dir:dirs){
        // 如果和原来的方向相同
        if(dir==lastDir||(lastDir.first==-1&&lastDir.second==-1)){
            dfs(matrix,M,N,dir,i+dir.first,j+dir.second,curTime+1);
        }
        else{
            dfs(matrix,M,N,dir,i+dir.first,j+dir.second,curTime+2);
        }
    }
    matrix[i][j]=temp;// 回溯
}

int main(){
    // 获取输入
    // int n,m;
    // cin>>n>>m;
    // vector<int> arr(n,0);
    // for(int i=0;i<n;++i){
    //     cin>>arr[i];
    // }
    // 案例输入
    int M=6,N=6;
    vector<string> matrix={"SBBBBB","BXXXXB","BBXBBB","XBBXXB","BXBBXB","BBXBEB"};
    vector<vector<int>> isVisited(M,vector<int>(N,0));
    // 执行程序
    for(int i=0;i<M;++i){
        for(int j=0;j<N;++j){
            if(matrix[i][j]=='S'){
                dfs(matrix,M,N,{-1,-1},i,j,0);
                break;
            }
        }
    }
    // 输出结果
    if(res==INT_MAX)cout<<-1;
    else cout<<res;
    system("pause"); 
    return 0;
}

// 构造试卷
// int main(){
//     // 获取输入
//     int n,m;
//     cin>>n>>m;
//     vector<int> arr(n,0);
//     for(int i=0;i<n;++i){
//         cin>>arr[i];
//     }
//     // 案例输入
//     // int n=5,m=3;
//     // vector<int> arr={1,2,3,4,5};
//     // 执行程序
//     int res=0;
//     if(m<=n){
//         while(arr[n-m]!=0){
//             sort(arr.begin(),arr.end());
//             res+=arr[n-m];
//             for(int i=n-1;i>=n-m;--i){
//             arr[i]=arr[i]-arr[n-m];
//             }
//             arr[n-m]=0;
//             sort(arr.begin(),arr.end());
//         }
       
//     }
//     // 输出结果
//     cout<<res;
//     system("pause"); 
//     return 0;
// }


// class Solution {
// public:
//     /**
//      * 代码中的类名、方法名、参数名已经指定，请勿修改，直接返回方法规定的值即可
//      *
//      * 
//      * @param str string字符串 
//      * @return string字符串
//      */
//     bool isFirst(char c){
//         return isalpha(c)||isdigit(c)||c=='_';
//     }
//     bool isNoFirst(char c){
//         return isalpha(c)||isdigit(c)||c=='_'||c=='.'||c=='-';
//     }
//     bool isBack(char c){
//         return isalpha(c)||isdigit(c)||c=='.';
//     }
//     string printEmail(string str) {
//         vector<string> res;
//         int n=str.length();
//         // 获取所有的@索引
//         queue<int> que;
//         for(int i=0;i<n;++i){
//             if(str[i]=='@') que.push(i);
//         }
//         if(que.size()==0) return "false";
//         else{
//             while(!que.empty()){
//                 int key=que.front();
//                 que.pop();
//                 int left=key-1,right=key+1;
//                 // 检查前缀是否合法
//                 int first=-1;
//                 while(left>=0){
//                     if(isFirst(str[left])) {
//                         left--;
//                         first=left;
//                     }
//                     else if(isNoFirst(str[left])){
//                         left--;
//                     }
//                     else break;
//                 }
//                 if(first<0||first==key-1) continue;
//                 // 检查后缀是否合法
//                 int dot=-1;
//                 int dotback=0;
//                 while(right<=n-1){
//                     // 如果是一个点
//                     if(str[right]=='.') {
//                         if(dot!=-1&&dotback<2){
//                             dot=-1;
//                             break;
//                         }
//                         dot=right;
//                         right++;
//                         dotback=0;
//                     }
//                     // 如果是点后数据
//                     else if(dot!=-1&&isalpha(str[right])){
//                         dotback++;
//                         right++;
//                     }
//                     else if(isBack(str[right])) right++;
//                     else break;
//                 }
//                 if(dot==-1||dotback<2) continue;
//                 string sub=str.substr(first+1,right-first-1);
//                 cout<<sub<<endl;
//                 res.push_back(sub);
//             }
//         }
//         if(res.size()==0) return "false";
//         string rt="true ";
//         for(int i=0;i<res.size();++i){
//             if(i!=res.size()-1) rt+=res[i]+" ";
//             else rt+=res[i];
//         }
//         return rt;
        
//     }
// };



// int main(){
//   // 获取输入
//   int n,m,k;
//   cin>>n>>m>>k;
//   // 执行程序
//   int len=n*2;
//   vector<int> b(len+1,0);
//   for(int i=1;i<=n;++i){
//     cin>>b[i];
//     b[len--]=b[i];
//   }
//   // 输出结果
//   if(k%(n*2)!=0){
//      cout<<b[k%(n*2)]<<endl;
//   } 
//   else{
//      cout<<b[n*2]<<endl;
//   }
//   return 0;
// }

// #include<bits/stdc++.h>
// using namespace std;

// int main(){
//     // 获取输入
//     string s;
//     getline(cin,s);
//     stringstream ss(s);
//     string t;
//     deque<int> arr;
//     while(getline(ss,t,' ')){
//         if(t=="") continue;
//         arr.push_back(stoi(t));
//     }
//     int k=arr.back();
//     arr.pop_back();
//     // 执行程序
//     unordered_map<int,int> dict;// 数字-获胜回合数
//     int win=0,lose=0;
//     while(true){
//         win=max(arr[0],arr[1]);
//         lose=min(arr[0],arr[1]);
//         arr.pop_front();
//         arr.pop_front();
//         arr.push_front(win);
//         arr.push_back(lose);
//         dict[win]++;
//         if(dict[win]>=3) break;
//     }
//     // 输出结果
//     cout<<win<<endl;
//     return 0;
// }

// #include<bits/stdc++.h>
// using namespace std;

// int main(){
//     // 获取输入
//     int n,tmp;
//     cin>>n;
//     vector<int> arr;
//     for(int i=0;i<n;++i){
//         cin>>tmp;
//         arr.push_back(tmp);
//     }
//     // 执行程序
//     sort(arr.begin(),arr.end());
//     int cur=1,res=0;
//     // 遍历所有程序
//     for(int i=1;i<n;++i){
//         // 如果两个数相同
//         if(arr[i]==arr[i-1]) continue;
//         // 如果当前数是连续递增
//         else if(arr[i]==arr[i-1]+1){
//             cur++;
//         }
//         // 如果当前数不是连续递增
//         else {
//             res=max(res,cur);
//             cur=1;
//         }
//     }
//     res=max(res,cur);
//     // 输出结果
//     cout<<res<<endl;
//     return 0;
// }

//客户端3
// #include<bits/stdc++.h>
// using namespace std;

// int main(){
//     // 获取输入
//     int n,x,tmp;
//     cin>>n>>x;
//     vector<int> arr;
//     for(int i=0;i<n;++i){
//         cin>>tmp;
//         arr.push_back(tmp);
//     }
//     // 执行程序
//     int res=0;
//     int low=arr[0]-x,up=arr[0]+x;
//     int left,right;
//     for(int i=1;i<n;++i){
//         tmp=arr[i];
//         left=tmp-x,right=tmp+x;
//         if(left>up||right<low){
//             res++;
//             low=left;
//             up=right;
//         }
//         else{
//             low=max(low,left);
//             up=min(up,right);
//         }
//     }
//     // 输出结果
//     cout<<res<<endl;
//     return 0;
// }







// int main() {
    
   

//     system("pause"); 
//     return 0;
// }




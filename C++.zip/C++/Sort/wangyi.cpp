/*
 * @Author: MRL Liu
 * @Date: 2022-02-02 21:35:48
 * @Description: 开发环境测试
 * @LastEditTime: 2022-02-16 02:05:33
 * @FilePath: \C++\io_test.cpp
 */
#include<bits/stdc++.h>
using namespace std; 

// 小红的数位删除  20%  15分
// 小红拿到了两个正整数a和b,每次操作可以选择其中一个正整数并删除其中一个数位
// 小红希望最终a是b的倍数或者b是a的倍数，问最少操作次数

// 嘤嘤的长城easy 13.33%  20分
// 长城数组中每一个元素左右两边元素相等，并且与它不相等。
// 长城数组:2 1 2 1 2     1 9 1 9
// 非长城数组: 2 1 3 2 4 
// 你每次可以将一个元素加一，使数组变成长城数组，问最少操作次数
int fun(vector<int>& arr){
    int n=arr.size();
    int res=0;
    // 找到最大值
    int max=0;
    for(int i=1;i<n;i++){
        if(arr[i]>max) max=arr[i];
    }
    // 最大值所在
    for(int i=0;i<n;i++){
        res+=max-arr[i];
    }
    return res;
}

int main1(){
    // 获取输入
    // int n,tmp;
    // cin>>n;
    //vector<int> arr;  1 1 4 5 1 4    答案：11
    vector<int> arr_odd={1,5,4};// 奇数索引数组
    vector<int> arr_even={1,4,1};// 偶数索引数组
    // bool flag=false;
    // for(int i=0;i<n;i++){
    //     cin>>tmp;
    //     if(flag) arr_even.push_back(tmp);
    //     else arr_odd.push_back(tmp);
    //     flag=!flag;
    // }
    // 案例输入
    // 执行程序
    int res=0;
    // 找到偶数列
    res+=fun(arr_odd);
    cout<<fun(arr_odd)<<endl;
    res+=fun(arr_even);
    cout<<fun(arr_even);
    // 输出结果
    cout<<res<<endl;

    system("pause"); 
    return 0;
}
// 小红的好e 0 31.58% 30分
// 输入一个仅有 r d e的字符串，修改其中某个字符为任意字符，好e为e字符既和r相邻也和d相邻
// 使得好e的个数最多，问最少操作次数




// 小红的V三元组 57.14% 35分
// 输入一个数组，问其中存在多少个三元组满足. 第1个数和第3个数相等，第1个数大于第2个数
// 三元组的数可以不连续
// int res=0;
// vector<int> path;
// unordered_map<int,int> dict;
// void dfs(vector<int>& arr,int startIndex){
//     if(path.size()>3) return;
//     if(path.size()==3){
//         if(path[0]==path[2]&&path[0]>path[1]) res++;
//         return;
//     }
//     // 遍历下一种可能
//     for(int i=startIndex;i<arr.size();i++){
//         if(path.size()==0) if(dict[arr[i]]<=1) continue;
//         if(path.size()==1) if(arr[i]>=path[0]) continue;
//         if(path.size()==2) if(arr[i]!=path[0]) continue;
//         path.push_back(arr[i]);
//         dfs(arr,i+1);
//         path.pop_back();
//     }
// }


// int main(){
//     // 获取输入
//     int n,tmp;
//     cin>>n;
//     vector<int> arr;
//     for(int i=0;i<n;i++){
//         cin>>tmp;
//         dict[tmp]++;
//         arr.push_back(tmp);
//     }
//     // 案例输入
//     int n=6;
//     vector<int> arr={3,1,3,4,3,4};
//     // 执行程序
//     dfs(arr,0);
//     // 输出结果
//     cout<<res<<endl;
//     system("pause"); 
//     return 0;
// }

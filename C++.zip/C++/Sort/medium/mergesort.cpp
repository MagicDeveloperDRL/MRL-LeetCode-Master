/*
 * @Author: MRL Liu
 * @Date: 2022-02-09 22:11:30
 * @Description: �鲢����
 * @LastEditTime: 2022-02-10 17:21:15
 * @FilePath: \C++\Sort\medium\mergesort.cpp
 */
#include<vector>
#include<iostream>
#include<string>
using namespace std;
// ��ʾ��������
void showArray(vector<int> &nums,string name="",int start=0){
    cout<<name;
    for (int i = start; i < nums.size(); i++)
    {
        cout<<nums[i]<<" ";
    }
    cout<<endl;
}

// 合并两个无序数组为一个有序数组
void merge(vector<int> &nums,int left,int right,int mid){
	vector<int> temp(right-left + 1);// 开辟的应用层缓存：数组结构
	int i = left;
	int j = mid + 1;// 
	int k = 0;// 负责遍历temp
	// 遍历左右两个小数组，结束后至少有一个小数组遍历完
	while (i <= mid && j <= right) {
		// 谁小移动谁
		if (nums[i] <= nums[j]) {
			temp[k++] = nums[i++];
		} else {
			temp[k++] = nums[j++];
		}
	}
	// 检查哪个小数组没遍历完
	while(i <= mid) temp[k++] = nums[i++];
	while(j <= right) temp[k++] = nums[j++];
	// 缓存temp的数据拷贝到nums
	for (i = 0; i < k; i++) {
		nums[left++] = temp[i];
	}
}
/*void mergeSort(vector<int> &nums, int left, int right){
    // 如果 left == right，表示数组只有一个元素，则不用递归排序
    if (left < right) {
        // 把大的数组分隔成两个数组
        int mid = left + (right - left) / 2;
        // 对左半部分进行排序
        mergeSort(nums, left, mid);
        // 对右半部分进行排序
        mergeSort(nums, mid + 1, right);
        merge(nums,left,right,mid);
        // 将两部分合并后再重新排一次序
        //1、先用一个临时数组把他们合并汇总起来
        // vector<int> temp(right - left + 1);
        // int i = left;
        // int j = mid + 1;
        // int k = 0;
        // //2、分别选取左右两半部分中的较小值放入临时数组
        // while (i <= mid && j <= right) {
        //     // 谁小先放谁到临时数组
        //     if (nums[i] < nums[j]) {
        //         temp[k++] = nums[i++];
        //     } else {
        //         temp[k++] = nums[j++];
        //     }
        // }
        // //3、跳出循环的条件i>mid或者j>right,此时两个小数组中有一个一定没有剩余，另一个有未放入临时数组的数
        // // 不知道哪个有剩余，干脆两者都判断下，有剩余直接进循环
        // while(i <= mid) temp[k++] = nums[i++];
        // while(j <= right) temp[k++] = nums[j++];
        // // 此时原有数组的左右部分全部复制到临时数组并已排序，把临时数组复制回原数组
        // for (i = 0; i < k; i++) {
        //     nums[left++] = temp[i];
        // }
    }
}*/

void mergeSort(vector<int> &nums, int left, int right){
	// 终止条件
    if (left < right) {
        int mid = left + (right - left) / 2;// 找到left、right
        mergeSort(nums, left, mid);// 将数组左边排序：1256
        mergeSort(nums, mid + 1, right);//将数组右边排序:3478
        merge(nums,left,right,mid);// 12345678
	}
    // if (left < right) {
    //     // 把大的数组分隔成两个数组
    //     int mid = left + (right - left) / 2;
    //     // 对左半部分进行排序
    //     mergeSort(nums, left, mid);
    //     // 对右半部分进行排序
    //     mergeSort(nums, mid + 1, right);
    //     merge(nums,left,right,mid);
    // }
	
}


int main()
{
    vector<int> nums={9,5,2,8,1,4,7,0,3,6};
    showArray(nums,"排序前：");
    mergeSort(nums, 0, nums.size()-1);
    showArray(nums,"排序后：");
    system("pause");
    return 0;
}
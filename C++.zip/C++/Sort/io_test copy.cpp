/*
 * @Author: MRL Liu
 * @Date: 2022-02-02 21:35:48
 * @Description: 开发环境测试
 * @LastEditTime: 2022-02-16 02:05:33
 * @FilePath: \C++\io_test.cpp
 */
#include<bits/stdc++.h>
using namespace std; 

// 扑克1
int main(){
    // 获取输入
    // int n;
    // cin>>n;
    // vector<int> arr;
    // int tmp;
    // int p=n;
    // while(p--){
    //     cin>>tmp;
    //     arr.push_back(tmp);
    // }
    // 案例输入
    int n=4;
    vector<int> arr={1,2,3,4};
    // 打印输入检查是否获取正确
    cout<<n<<endl;
    cout<<"arr size:"<<arr.size()<<endl;
    for(int x:arr) cout<<x<<" "; 
    cout<<endl;
    // 处理程序
    vector<int> res(n,0);
    deque<int> d;

    for (int i = 0; i < n; i++) d.push_back(n-i-1);//n-1,n-2...0
    cout<<endl;
    for (int i = 0; i < n; i++) {
        // Alice操作
        d.push_front(d.back());
        d.pop_back();
        // Bob操作
        d.push_front(d.back());
        d.pop_back();

        res[d.back()] = arr[i];
        d.pop_back();
    }
    // 输出结果
    for(int x:res) cout<<x<<" ";
    system("pause"); 
    return 0;
}
// 扑克2
int main(){
    // 案例输入
    int n=4;
    vector<int> arr={4,2,1,3};
    vector<int> arr={4,2,1,3};
    // 打印输入检查是否获取正确
    cout<<n<<endl;
    cout<<"arr size:"<<arr.size()<<endl;
    for(int x:arr) cout<<x<<" "; 
    cout<<endl;
    // 处理程序
    vector<int> res(n,0);
    deque<int> d;

    for (int i = 0; i < n; i++) d.push_back(arr[i]);//0,1,...,n-2,n-1
    cout<<endl;
    for (int i = 0; i < n; i++) {
        // Alice操作
        d.push_back(d.front());
        d.pop_front();
        // Bob操作
        d.push_back(d.front());
        d.pop_front();

        res[i]=d.front();
        //res[d.back()] = arr[i];
        d.pop_front();
    }
    // 输出结果
    for(int x:res) cout<<x<<" ";
    system("pause"); 
    return 0;
}
// 合法元数组
// int main(){
//   // 获取输入
//   int n;
//   cin>>n;
//   //cout<<n<<endl;
//   vector<int> arr;
//   int tmp;
//   int p=n;
//   while(p--){
//     cin>>tmp;
//     //cout<<tmp<<" ";
//     arr.push_back(tmp);
//   }
//   //cout<<endl;
//   //cout<<arr.size()<<endl;
//   // 定义二维数组
//   int res=0;
//   if(n<3) cout<<res<<endl;
//   else{
//     for(int k=2;k<n;++k){
//       int left=arr[k-2]-arr[k-1];
//       int right=2*arr[k-1]-arr[k];
//       if(left==right) res++;
//     }
//   }
//   // 输出结果
//   cout<<rand()%n<<endl;
//   //cout<<7<<endl;
//   return 0;
// }
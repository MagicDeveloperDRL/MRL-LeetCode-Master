/*
 * @Author: MRL Liu
 * @Date: 2022-02-07 21:56:14
 * @Description: װ����ģʽ
 * @LastEditTime: 2022-02-07 23:05:29
 * @FilePath: \C++\DesignMode\Decorator\Decorator.cpp
 */

#include <iostream>
using namespace std;

class Food
{
public:
	virtual void Cooking() = 0;//���
};



class Meat :public Food
{
public:
	void Cooking()
	{
		cout << "Cooking Meat" << endl;
	}
};

class Decorator : public Food
{
protected:
	Decorator(Food* food) :m_food(food){};
	Food* m_food;
};

class SweetDecorator :public Decorator
{
public:
	SweetDecorator(Food* food) :Decorator(food){};//���û���Ĺ�����
	void Cooking()
	{
		cout << "Add Sweet" << endl;
		m_food->Cooking();
	}


};

class SpicyDecorator :public Decorator
{
public:
	SpicyDecorator(Food* food) :Decorator(food){};//���û���Ĺ�����

	void Cooking()
	{
		cout << "Add Spicy" << endl;
		m_food->Cooking();
	}
};

int main(int argc, char *argv[])
{
	//������
	Food* meat = new Meat();
	//����װ���� ��ζ����ζ
	Decorator* sweetDecorator= new SweetDecorator(meat);
	Decorator* spicyDecorator = new SpicyDecorator(meat);
	//�����
	sweetDecorator->Cooking();
	cout << "*********************" << endl;
	//������
	spicyDecorator->Cooking();
	cout << "*********************" << endl;
	//������������
	Decorator* sweetSpicyDecorator= new SpicyDecorator(sweetDecorator);
	sweetSpicyDecorator->Cooking();

   	system("pause");
    return 0;
}
/*
 * @Author: MRL Liu
 * @Date: 2022-02-07 23:06:06
 * @Description: ģ��ģʽ
 * @LastEditTime: 2022-02-07 23:14:38
 * @FilePath: \C++\DesignMode\Template\Template.cpp
 */
#include<iostream>
using namespace std;

class PayTemplate{
public:
    void pay(int count){
        this->scanCode();
        this->getPassWord();
        this->payMoney(count);
    };
protected:
    void scanCode(){cout<<"�ѳɹ�ɨ���ά��"<<endl;};
    void getPassWord(){cout<<"�ѳɹ���ȡ֧������"<<endl;};
    virtual void payMoney(int count)=0;
};


class WeChatPayStrategy:public PayTemplate{
    void payMoney(int count) override{
        cout<<"΢������֧��"<<count<<endl;
    }
};

class AliPayStrategy:public PayTemplate{
    void payMoney(int count) override{
        cout<<"֧��������֧��"<<count<<endl;
    }
};

int main(int argc, char *argv[])
{
    PayTemplate* payTemplate1 = new WeChatPayStrategy;
    payTemplate1->pay(100);
    PayTemplate* payTemplate2 = new AliPayStrategy;
    payTemplate2->pay(100);
    delete payTemplate1;
    delete payTemplate2;

    system("pause");
    return 0;
}
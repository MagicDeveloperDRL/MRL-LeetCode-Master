/*
 * @Author: MRL Liu
 * @Date: 2022-02-06 21:52:47
 * @Description: ��
 * @LastEditTime: 2022-02-06 21:54:04
 * @FilePath: \C++\DesignMode\Observer\subject.cpp
 */
class Observer;


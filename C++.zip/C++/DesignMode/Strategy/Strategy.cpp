/*
 * @Author: MRL Liu
 * @Date: 2022-02-07 20:42:56
 * @Description: ��
 * @LastEditTime: 2022-02-07 21:27:47
 * @FilePath: \C++\DesignMode\Strategy\Strategy.cpp
 */
#include<iostream>
using namespace std;

class Strategy{
public:
    virtual void pay1(int count)=0; // ҵ���߼��ӿڣ�����֧��
    virtual void pay2(int count)=0; // ҵ���߼��ӿڣ�����֧��
};

class Context{
public:
    Context(Strategy* strategy,int payMethord=1){
        this->strategy=strategy;
        this->payMethord = payMethord;
    };
    void pay(int count){
        if(this->payMethord==1)
            this->strategy->pay1(count);
        else if(this->payMethord==2)
            this->strategy->pay2(count);
        else{
            cout<<"�޴�֧����ʽ��֧��ʧ��"<<endl;
        }
    }
private:
    Strategy* strategy;
    int payMethord;
};

class WeChatPayStrategy:public Strategy{
    void pay1(int count) override{
        cout<<"΢������֧��"<<count<<endl;
    }
    void pay2(int count) override{
        cout<<"΢������֧��"<<count<<endl;
    }
};

class AliPayStrategy:public Strategy{
    void pay1(int count) override{
        cout<<"֧��������֧��"<<count<<endl;
    }
    void pay2(int count) override{
        cout<<"֧��������֧��"<<count<<endl;
    }
};

int main(int argc, char *argv[])
{
    Context* context1 = new Context(new WeChatPayStrategy,1);
    context1->pay(100);
    Context* context2 = new Context(new AliPayStrategy,2);
    context2->pay(100);
    delete context1;
    delete context2;
    
    system("pause");
    return 0;
}
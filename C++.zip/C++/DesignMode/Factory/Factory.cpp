/*
 * @Author: MRL Liu
 * @Date: 2022-02-05 23:09:36
 * @Description: ����ģʽ
 * @LastEditTime: 2022-02-06 21:29:19
 * @FilePath: \C++\DesignMode\Product\Factory.cpp
 */
#include<iostream>
using namespace std;

//��Ʒ����
class Product
{
public:
    virtual int operation(int a, int b) = 0;//
protected:
    Product(){};
};

//��Ʒ������Add
class Product_Add : public Product{
public:
	int operation(int a, int b){
		return a + b;
	}
};
//��Ʒ������Mul
class Product_Mul : public Product{
public:
	int operation(int a, int b){
		return a * b;
	}
};

//������
class Factory{
public:
	virtual Product* Create()=0;
};

//������
class Factory_Add:public Factory{
public:
	Product* Create(){
		return new Product_Add;
	}
};

//������
class Factory_Mul:public Factory{
public:
	Product* Create(){
		return new Product_Mul;
	}
	
};

int main(){
    Factory_Add* factory_add = new Factory_Add();
	Factory_Mul* factory_mul = new Factory_Mul();
    int add_result = factory_add->Create()->operation(1, 2);
	int mul_result = factory_mul->Create()->operation(1, 2);
	cout <<"op_add��" <<add_result << endl;
	cout <<"op_multiply��" << mul_result << endl;
    system("pause");
    return 0;
}
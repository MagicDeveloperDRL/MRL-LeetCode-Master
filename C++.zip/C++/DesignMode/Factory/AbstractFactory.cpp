/*
 * @Author: MRL Liu
 * @Date: 2022-02-06 21:28:21
 * @Description: ��
 * @LastEditTime: 2022-02-06 21:34:44
 * @FilePath: \C++\DesignMode\Product\AbstractFactory.cpp
 */
#include<iostream>
using namespace std;

//��Ʒ����
class Product_A
{
public:
    virtual int operation(int a, int b) = 0;//
protected:
    Product_A(){};
};

//��Ʒ������Add
class Product_A_Add : public Product_A{
public:
	int operation(int a, int b){
		return a + b;
	}
};
//��Ʒ������Mul
class Product_A_Mul : public Product_A{
public:
	int operation(int a, int b){
		return a * b;
	}
};

//��Ʒ����
class Product_B
{
public:
    virtual int operation(int a, int b) = 0;//
protected:
    Product_B(){};
};

//��Ʒ������Add
class Product_B_Add : public Product_B{
public:
	int operation(int a, int b){
		return (a + b)*2;
	}
};
//��Ʒ������Mul
class Product_B_Mul : public Product_B{
public:
	int operation(int a, int b){
		return a * b*2;
	}
};

//������
class Factory{
public:
	virtual Product_A* Create_Product_A()=0;
	virtual Product_B* Create_Product_B()=0;
};

//������
class Factory_Add:public Factory{
public:
	Product_A* Create_Product_A(){
		return new Product_A_Add;
	}
	Product_B* Create_Product_B(){
		return new Product_B_Add;
	}
};

//������
class Factory_Mul:public Factory{
public:
	Product_A* Create_Product_A(){
		return new Product_A_Mul;
	}
	Product_B* Create_Product_B(){
		return new Product_B_Mul;
	}
	
};

int main(){
    Factory_Add* factory_add = new Factory_Add();
	Factory_Mul* factory_mul = new Factory_Mul();
    int A_add_result = factory_add->Create_Product_A()->operation(1, 2);
	int A_mul_result = factory_mul->Create_Product_A()->operation(1, 2);
	int B_add_result = factory_add->Create_Product_B()->operation(1, 2);
	int B_mul_result = factory_mul->Create_Product_B()->operation(1, 2);
	cout <<"A_op_add��" <<A_add_result << endl;
	cout <<"A_op_multiply��" << A_mul_result << endl;
	cout <<"B_op_add��" <<B_add_result << endl;
	cout <<"B_op_multiply��" << B_mul_result << endl;
    system("pause");
    return 0;
}
/*
 * @Author: MRL Liu
 * @Date: 2022-02-05 23:09:36
 * @Description: ��
 * @LastEditTime: 2022-02-06 21:29:06
 * @FilePath: \C++\DesignMode\Product\SimpleFactory.cpp
 */

#include<iostream>
using namespace std;

//��Ʒ����
class Product
{
public:
    virtual int operation(int a, int b) = 0;//
protected:
    Product(){};
};

//��Ʒ������Add
class Product_Add : public Product{
public:
	int operation(int a, int b){
		return a + b;
	}
};
//��Ʒ������Mul
class Product_Mul : public Product{
public:
	int operation(int a, int b){
		return a * b;
	}
};

//������
class Factory{
public:
	Product* Create(int i){
		switch (i){
		case 1:
			return new Product_Add;
			break;
		case 2:
			return new Product_Mul;
			break;
		default:
			break;
		}
	}
};


int main(){
    Factory* factory = new Factory();
    int add_result = factory->Create(1)->operation(1, 2);
	int mul_result = factory->Create(2)->operation(1, 2);
	cout <<"op_add��" <<add_result << endl;
	cout <<"op_multiply��" << mul_result << endl;
    system("pause");
    return 0;
}
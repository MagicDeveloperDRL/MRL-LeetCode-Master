/*
 * @Author: MRL Liu
 * @Date: 2022-02-07 23:34:48
 * @Description: ������ģʽ
 * @LastEditTime: 2022-02-08 00:09:32
 * @FilePath: \C++\DesignMode\Builder\Builder.cpp
 */
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Product
{
public:
    void AddPart(string part){
        m_Parts.push_back(part);
    };
    void Show(){
        cout << "��ɲ���:" << endl;
        for(auto part : m_Parts)
        {
            cout << part << endl;
        }
    };

    int PartsCount(){
        return m_Parts.size();
    };
private:
    vector<string>   m_Parts;
};


class Builder
{
public:
    Builder(){m_Product = new Product();};
    virtual void AddBachelor()=0;
    virtual void AddMaster()=0;
    virtual void AddDoctor()=0;
    Product* GetProduct(){
        if(m_Product->PartsCount() > 0)
            return m_Product;
        else{
            cout << "�������" << std::endl;
            return NULL;
        }
    };
protected:
    Product*    m_Product;
};

class Director
{
public:
    Product* ConstructBachelor(Builder* builder){
        builder->AddBachelor();
        return builder->GetProduct();
    };
    Product* ConstructMaster(Builder* builder){
        builder->AddBachelor();
        builder->AddMaster();
        return builder->GetProduct();
    };
    Product* ConstructDocter(Builder* builder){
        builder->AddBachelor();
        builder->AddMaster();
        builder->AddDoctor();
        return builder->GetProduct();
    };
};


class TJUerBuilder: public Builder
{
public:
    void AddBachelor() override{
        m_Product->AddPart("���ѧʿѧλ");
    };
    void AddMaster() override{
        m_Product->AddPart("���˶ʿѧλ");
    };
    void AddDoctor() override{
        m_Product->AddPart("���ʿѧλ");
    };
};
class NKUerBuilder: public Builder
{
public:
    void AddBachelor() override{
        m_Product->AddPart("�Ͽ�ѧʿѧλ");
    };
    void AddMaster() override{
        m_Product->AddPart("�Ͽ�˶ʿѧλ");
    };
    void AddDoctor() override{
        m_Product->AddPart("�Ͽ���ʿѧλ");
    };
};

int main(int argc, char *argv[])
{
    Director director;
    
    Product* tjuer = director.ConstructBachelor(new TJUerBuilder);
    tjuer->Show();

    Product* nkuer = director.ConstructDocter(new NKUerBuilder);
    nkuer->Show();

    system("pause");
    return 0;
}

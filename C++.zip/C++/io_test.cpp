/*
 * @Author: MRL Liu
 * @Date: 2022-02-02 21:35:48
 * @Description: 开发环境测试
 * @LastEditTime: 2022-02-16 02:05:33
 * @FilePath: \C++\io_test.cpp
 */
#include<bits/stdc++.h>
using namespace std; 

// str1是色块，str2是颜料
int fun2(string str1,string str2){
	unordered_map<char,int> dict1,dict2;
	for(char c:str1) dict1[c]++;
	for(char c:str2) dict2[c]++;
	int res = 0;
	for (auto it = dict2.begin(); it != dict2.end(); it++) {
		if (it->second <= dict1[it->first]) {
			res += it->second;
		}
		else {
			res += dict1[it->first];
		}
	}
	return res;
}

int fun1(string str){
	//判断长度为0的情况
	if (str=="") return 0;
	unordered_map<char,int> dict;
	int res = 0;
	//记录每个子字符串出现的位置的前一个位置，初始为-1
	int pre = -1;
	for (int i=0; i<str.length(); i++) {
		//若自字符串中包含当前字符，则计算长度最大值，变更pre的值
		int tmp=dict.find(str[i]) == dict.end() ? -1 : dict[str[i]];
		pre = max(pre, tmp);
		res = max(res, i - pre);
		dict[str[i]]= i;
	}
	return res;
}


int main(){
	// 获取输入
	int res=fun2("ABC","ACD");
	cout<<res<<endl;
	system("pause");
  	return 0;
}







